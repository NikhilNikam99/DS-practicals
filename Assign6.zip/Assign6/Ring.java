import java.util.*;

class Rr {
    int id, f = 0;
    String state = "active";
}

public class Ring {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Rr[] proc = new Rr[10];
        int num;

        while (true) {
            System.out.print("Enter number of processes (1-10): ");
            num = sc.nextInt();
            if (num >= 1 && num <= 10) break;
            System.out.println("Invalid input.");
        }

        for (int i = 0; i < num; i++) {
            proc[i] = new Rr();
            System.out.print("Enter ID for process " + (i + 1) + ": ");
            proc[i].id = sc.nextInt();
        }

        Arrays.sort(proc, 0, num, Comparator.comparingInt(p -> p.id));
        for (int i = 0; i < num; i++)
            System.out.print("[" + i + "] " + proc[i].id + " ");

        proc[num - 1].state = "inactive";
        System.out.println("\nProcess " + proc[num - 1].id + " is coordinator");

        while (true) {
            System.out.print("\n1. Election  2. Quit: ");
            int ch = sc.nextInt();
            if (ch == 2) {
                System.out.println("Program terminated.");
                break;
            }
            if (ch != 1) {
                System.out.println("Invalid choice.");
                continue;
            }

            System.out.print("Enter initiator process number (0-" + (num - 1) + "): ");
            int init = sc.nextInt();
            if (init < 0 || init >= num) {
                System.out.println("Invalid process number.");
                continue;
            }

            int temp1 = (init + 1) % num, curr = init;
            List<Integer> list = new ArrayList<>();

            while (curr != temp1) {
                if (proc[temp1].state.equals("active") && proc[temp1].f == 0) {
                    System.out.println("Msg from " + proc[curr].id + " to " + proc[temp1].id);
                    proc[temp1].f = 1;
                    curr = temp1;
                    list.add(proc[temp1].id);
                }
                temp1 = (temp1 + 1) % num;
            }

            System.out.println("Msg from " + proc[curr].id + " to " + proc[temp1].id);
            list.add(proc[temp1].id);

            int max = Collections.max(list);
            System.out.println("Process " + max + " selected as coordinator");

            for (int i = 0; i < num; i++) {
                if (proc[i].id == max)
                    proc[i].state = "inactive";
                proc[i].f = 0; // reset flag
            }
        }
        sc.close();
    }
}
