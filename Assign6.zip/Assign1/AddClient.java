import java.rmi.*;

public class AddClient {
    public static void main(String args[]) {
        try {
            String addServerURL = "rmi://127.0.0.1/AddServer";
            AddServerIntf addServerIntf = (AddServerIntf) Naming.lookup(addServerURL);

            // Use args[0] for the first argument and args[1] for the second argument
            double d1 = Double.valueOf(args[0]);
            double d2 = Double.valueOf(args[1]);

            System.out.println("The first number is: " + d1);
            System.out.println("The second number is: " + d2);
            System.out.println("The sum is: " + addServerIntf.add(d1, d2));
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}
