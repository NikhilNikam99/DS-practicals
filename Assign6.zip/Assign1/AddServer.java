import java.rmi.*;
import java.rmi.server.*;

public class AddServer {
    public static void main(String args[]) {
        try {
            // Create the server implementation
            AddServerImpl addServerImpl = new AddServerImpl();
            // Bind the implementation to the RMI registry
            Naming.rebind("//127.0.0.1/AddServer", addServerImpl);
            System.out.println("Server is ready and waiting for client requests...");
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}
